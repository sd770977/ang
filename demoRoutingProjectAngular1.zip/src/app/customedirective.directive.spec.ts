import { CustomedirectiveDirective } from './customedirective.directive';

describe('CustomedirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomedirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
