export class User{
    userId:number;
	firstName:string;
	surName :string;
	age :number;
	email :string;
	occupation :string;
	pincode :number;
	city :string;
	state :string;
	country :string;
	isDeleted :boolean;
	dob :Date;
	doj :Date;
}