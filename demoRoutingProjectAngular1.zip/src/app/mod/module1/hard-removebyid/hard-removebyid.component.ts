import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hard-removebyid',
  templateUrl: './hard-removebyid.component.html',
  styleUrls: ['./hard-removebyid.component.css']
})
export class HardRemovebyidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
