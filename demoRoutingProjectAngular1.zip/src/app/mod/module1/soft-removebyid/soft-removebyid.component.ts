import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-soft-removebyid',
  templateUrl: './soft-removebyid.component.html',
  styleUrls: ['./soft-removebyid.component.css']
})
export class SoftRemovebyidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
