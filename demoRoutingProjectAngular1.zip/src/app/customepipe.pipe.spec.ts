import { CustomepipePipe } from './customepipe.pipe';

describe('CustomepipePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomepipePipe();
    expect(pipe).toBeTruthy();
  });
});
